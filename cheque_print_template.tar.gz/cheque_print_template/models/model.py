from openerp import api, fields, models


class AccountPayment(models.Model):
    _inherit = 'account.payment'


    def split_date(self):
        date_list=[]
        if self.payment_date:
            dates=self.payment_date.replace('-','')
            for date in dates:
                date_list.append(date)
        return date_list

    @api.multi
    def action_cheque_print(self):
        self.ensure_one()
        return self.env['report'].get_action(self, 'cheque_print_template.report_cheque_print_template')


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    account_pay_cheque=fields.Boolean('A/c Pay Cheque')